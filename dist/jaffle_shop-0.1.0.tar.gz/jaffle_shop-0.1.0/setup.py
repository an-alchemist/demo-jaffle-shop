from setuptools import setup, find_packages

setup(
    name='jaffle_shop',
    version='0.1.0',
    packages=find_packages(),
    description='DBT project jaffle_shop with custom utilities',
    author='TEST DBT',
    author_email='your.email@example.com',
    url='URL to your project if available',
)